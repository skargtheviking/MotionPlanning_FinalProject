To run the program open up a terminal and navigate to this folder (commands cd and ls can help).

Then to run the program type:

python run_graph_search

This will run all of the functions to output the graphs found in the report.
If you only want to run a section of these comment out the functions you don't want to run.

To change the graphs to ones not requested for in the assignment, mearly change the map used within the function (i.e. map1.txt -> map2.txt)

