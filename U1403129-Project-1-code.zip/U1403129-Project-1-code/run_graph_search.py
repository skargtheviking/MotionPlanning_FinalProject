import graph_search

def run_dfs(map_path,actions=graph_search._ACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.dfs(g.init_pos, g.transition, g.is_goal, actions)
    g.display_map(res[0][0],res[1])
def run_rdfs(map_path,actions=graph_search._REVERSE_ACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.dfs(g.init_pos, g.transition, g.is_goal, actions)
    g.display_map(res[0][0],res[1])
def run_idfs(map_path,m,actions=graph_search._ACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.idfs(g.init_pos, g.transition, g.is_goal, actions, m)
    g.display_map(res[0][0],res[1])
def run_bfs(map_path,actions=graph_search._ACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.bfs(g.init_pos, g.transition, g.is_goal, actions)
    g.display_map(res[0][0],res[1])
def run_ucs(map_path,actions=graph_search._ACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.uniform_cost_search(g.init_pos, g.transition, g.is_goal, actions)
    g.display_map(res[0][0],res[1])
def run_ducs(map_path,actions=graph_search._ACTIONS_2):
    g = graph_search.GridMap(map_path)
    res = graph_search.uniform_cost_search(g.init_pos, g.transition, g.is_goal, actions)
    g.display_map(res[0][0],res[1])
def run_As(map_path,actions=graph_search._ACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.a_star_search(g.init_pos, g.transition, g.is_goal, actions,g.euclidean_heuristic)
    g.display_map(res[0][0],res[1])
def run_mAs(map_path,actions=graph_search._ACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.a_star_search(g.init_pos, g.transition, g.is_goal, actions,g.manhattan_heuristic)
    g.display_map(res[0][0],res[1])
def run_dAs(map_path,actions=graph_search._ACTIONS_2):
    g = graph_search.GridMap(map_path)
    res = graph_search.a_star_search(g.init_pos, g.transition, g.is_goal, actions,g.euclidean_heuristic)
    g.display_map(res[0][0],res[1])
def run_dmAs(map_path,actions=graph_search._ACTIONS_2):
    g = graph_search.GridMap(map_path)
    res = graph_search.a_star_search(g.init_pos, g.transition, g.is_goal, actions,g.manhattan_heuristic)
    g.display_map(res[0][0],res[1])
def run_2Dbfs(map_path,actions=graph_search._2DACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.bfs(g.init_pos, g.transition, g.is_goal, actions)
    g.display_map(res[0][0],res[1])
def run_2Ddfs(map_path,actions=graph_search._2DACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.dfs(g.init_pos, g.transition, g.is_goal, actions)
    g.display_map(res[0][0],res[1])
def run_2Ducs(map_path,actions=graph_search._2DACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.uniform_cost_search(g.init_pos, g.transition, g.is_goal, actions)
    g.display_map(res[0][0],res[1])
def run_2DAs(map_path,actions=graph_search._2DACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.a_star_search(g.init_pos, g.transition, g.is_goal, actions,g.euclidean_heuristic)
    g.display_map(res[0][0],res[1])
def run_2DmAs(map_path,actions=graph_search._2DACTIONS):
    g = graph_search.GridMap(map_path)
    res = graph_search.a_star_search(g.init_pos, g.transition, g.is_goal, actions,g.manhattan_heuristic)
    g.display_map(res[0][0],res[1])

if __name__ == '__main__':

    #### 1.1 Depth First Search ####
    goal_visited = run_dfs('./map0.txt')
    
    #### 1.2 Depth First Search ####
    goal_visited = run_dfs('./map1.txt')
    
    #### 1.3 Depth First Search ####
    goal_visited = run_dfs('./map2.txt')
    
    #### 1.5 Depth First Search ####
    goal_visited = run_rdfs('./map0.txt')
    goal_visited = run_rdfs('./map1.txt')
    
    #### 1.6 Depth First Search ####
    goal_visited = run_idfs('./map0.txt', 10)
    goal_visited = run_idfs('./map1.txt', 32)

    #### 2.1 Breadth First Search ####
    goal_visited = run_bfs('./map0.txt')
    
    #### 2.2 Breadth First Search ####
    goal_visited = run_bfs('./map1.txt')
    
    #### 2.3 Breadth First Search ####
    goal_visited = run_bfs('./map2.txt')
    
    #### 3.1 Uniform Cost Search ####
    goal_visited = run_ucs('./map0.txt')

    #### 3.2 Uniform Cost Search ####
    goal_visited = run_ucs('./map1.txt')

    #### 3.3 Uniform Cost Search ####
    goal_visited = run_ducs('./map0.txt')
    goal_visited = run_ducs('./map1.txt')
    goal_visited = run_ducs('./map2.txt')

    #### 4.1 A* Search ####
    goal_visited = run_As('./map0.txt')
    goal_visited = run_As('./map1.txt')
    goal_visited = run_As('./map2.txt')

    #### 4.2 A* Search ####
    goal_visited = run_mAs('./map0.txt')
    goal_visited = run_mAs('./map1.txt')
    goal_visited = run_mAs('./map2.txt')

    #### 4.3 A* Search ####
    goal_visited = run_dAs('./map0.txt')
    goal_visited = run_dAs('./map1.txt')
    goal_visited = run_dAs('./map2.txt')
    goal_visited = run_dmAs('./map0.txt')
    goal_visited = run_dmAs('./map1.txt')
    goal_visited = run_dmAs('./map2.txt')

    #### 5.1 Graph Search with 2D Pose ####
    goal_visited = run_2Dbfs('./map1.txt')

    #### 5.2 Graph Search with 2D Pose ####
    goal_visited = run_2Ddfs('./map1.txt')

    #### 5.4 Graph Search with 2D Pose ####
    goal_visited = run_2Ducs('./map1.txt')

    #### 5.5 Graph Search with 2D Pose ####
    goal_visited = run_2DAs('./map1.txt')
    goal_visited = run_2DmAs('./map1.txt')
