#!/usr/bin/env python
'''
Package providing helper classes and functions for performing graph search operations for planning.
'''
from asyncio.windows_events import NULL
from queue import Empty
import sys
from types import NoneType
import numpy as np
import heapq
import matplotlib.pyplot as plotter
from math import hypot, sqrt

_DEBUG = False                                                      ## Is this a debugging run?
_DEBUG_END = True                                                   ## Do we end debugging?
_ACTIONS = ['u','d','l','r']                                        ## Actions to allow for movement in only the cardinal directions
_ACTIONS_2 = ['u','d','l','r','ne','nw','sw','se']                  ## Actions to allow for diagonal movement
_2DACTIONS = ['f', 'tl', 'tr']                                      ## Actions that dictact either moving forward, turning left or turning right
_REVERSE_ACTIONS = ['r','l','d','u']                                ## Actions to allow for movement in only the cardinal directions in a reverse order from the first _ACTIONS
_T = 2                                                              ## indicates the use of the theta for the .state
_X = 1                                                              ## indicates the use of the x value for the .state
_Y = 0                                                              ## indicates the use of the y value for the .state
_GOAL_COLOR = 0.75                                                  ## Makes the goal color a green color
_INIT_COLOR = 0.25                                                  ## Makes the inital starting color an orange color 
_PATH_COLOR_RANGE = _GOAL_COLOR-_INIT_COLOR                         ## Creates a gradiant from orange to green along the action_path
_VISITED_COLOR = 0.9                                                ## Makes the visited non-path colors blue


class GridMap:                                                      
    '''
    Class to hold a grid map for navigation. Reads in a map.txt file of the format
    0 - free cell, x - occupied cell, g - goal location, i - initial location.
    Additionally provides a simple transition model for grid maps and a convience function
    for displaying maps.
    '''
    def __init__(self, map_path=None):
        '''
        Constructor. Makes the necessary class variables. Optionally reads in a provided map
        file given by map_path.

        map_path (optional) - a string of the path to the file on disk
        '''
        self.rows = None
        self.cols = None
        self.goal = None
        self.init_pos = None
        self.occupancy_grid = None
        if map_path is not None:
            self.read_map(map_path)

    def read_map(self, map_path):
        '''
        Read in a specified map file of the format described in the class doc string.

        map_path - a string of the path to the file on disk
        '''
        map_file = open(map_path,'r')
        lines = [l.rstrip().lower() for l in map_file.readlines()]
        map_file.close()
        self.rows = len(lines)
        self.cols = max([len(l) for l in lines])
        if _DEBUG:
            print('rows', self.rows)
            print('cols', self.cols)
            print(lines)
        self.occupancy_grid = np.zeros((self.rows, self.cols), dtype=np.bool)
        for r in range(self.rows):
            for c in range(self.cols):
                if lines[r][c] == 'x':
                    self.occupancy_grid[r][c] = True
                if lines[r][c] == 'g':
                    self.goal = (r,c)
                elif lines[r][c] == 'i':
                    self.init_pos = (r,c,0)

    def is_goal(self,s):
        '''
        Test if a specifid state is the goal state

        s - tuple describing the state as (row, col) position on the grid.

        Returns - True if s is the goal. False otherwise.
        '''
        return (s[_X] == self.goal[_X] and
                s[_Y] == self.goal[_Y])

    def transition(self, s, a):
        '''
        Transition function for the current grid map.

        s - tuple describing the state as (row, col) position on the grid.
        a - the action to be performed from state s

        returns - s_prime, the state transitioned to by taking action a in state s.
        If the action is not valid (e.g. moves off the grid or into an obstacle)
        returns the current state.
        '''
        new_pos = list(s[:])
        if a == 'f':
            if s[_T] == 0:
                a = 'u'
            elif s[_T] == 1:
                a = 'ne'
            elif s[_T] == 2:
                a = 'r'
            elif s[_T] == 3:
                a = 'se'
            elif s[_T] == 4:
                a = 'd'
            elif s[_T] == 5:
                a = 'sw'
            elif s[_T] == 6:
                a = 'l'
            elif s[_T] == 7:
                a = 'nw'

        # Ensure action stays on the board
        if a == 'u':
            if s[_Y] > 0:
                new_pos[_Y] -= 1
        elif a == 'd':
            if s[_Y] < self.rows - 1:
                new_pos[_Y] += 1
        elif a == 'l':
            if s[_X] > 0:
                new_pos[_X] -= 1
        elif a == 'r':
            if s[_X] < self.cols - 1:
                new_pos[_X] += 1
        elif a == 'sw':
            if s[_X] > 0 and s[_Y] < self.rows - 1:
                new_pos[_X] -= 1
                new_pos[_Y] += 1
        elif a == 'se':
            if  s[_X] < self.cols - 1 and s[_Y] < self.rows - 1:
                new_pos[_X] += 1
                new_pos[_Y] += 1
        elif a == 'nw':
            if s[_X] > 0 and s[_Y] > 0:
                new_pos[_X] -= 1
                new_pos[_Y] -= 1
        elif a == 'ne':
            if  s[_X] < self.cols - 1 and s[_Y] > 0:
                new_pos[_X] += 1
                new_pos[_Y] -= 1
        elif a == 'tl':
            new_pos[_T] -= 1
            if new_pos[_T] < 0:
                new_pos[_T] = 7
        elif a == 'tr':
            new_pos[_T] += 1
            if new_pos[_T] > 7:
                new_pos[_T] = 0 
        else:
            print('Unknown action:', str(a))

        # Test if new position is clear
        if self.occupancy_grid[new_pos[0], new_pos[1]]:
            s_prime = tuple(s)
        else:
            s_prime = tuple(new_pos)
        return s_prime


    def display_map(self, path=[], visited={}, filename=None):
        '''
        Visualize the map read in. Optionally display the resulting plan and visisted nodes

        path - a list of tuples describing the path take from init to goal
        visited - a set of tuples describing the states visited during a search
        filename - relative path to file where image will be saved
        '''
        display_grid = np.array(self.occupancy_grid, dtype=np.float32)

        # Color all visited nodes if requested
        for v in visited:
            display_grid[v[0],v[1]] = _VISITED_COLOR
        # Color path in increasing color from init to goal
        for i, p in enumerate(path):
            disp_col = _INIT_COLOR + _PATH_COLOR_RANGE*(i+1)/len(path)
            display_grid[p[0],p[1]] = disp_col

        display_grid[self.init_pos[0],self.init_pos[1]] = _INIT_COLOR
        display_grid[self.goal] = _GOAL_COLOR

        # Plot display grid for visualization
        imgplot = plotter.imshow(display_grid)
        # Set interpolation to nearest to create sharp boundaries
        imgplot.set_interpolation('nearest')
        # Set color map to diverging style for contrast
        imgplot.set_cmap('Spectral')
        if filename is not None:
            plotter.savefig(filename)
        plotter.show()
        
    def euclidean_heuristic(self, s):
        dis = sqrt((s.state[0]-self.goal[0])**2 + (s.state[1]-self.goal[1])**2)
        return dis

    def manhattan_heuristic(self, s):
        dis = abs(s.state[0]-self.goal[0]) + abs(s.state[1]-self.goal[1])
        return dis

    def uninformed_heuristic(self, s):
        '''
        Example of how a heuristic may be provided. This one is admissable, but dumb.

        s - tuple describing the state as (row, col) position on the grid.

        returns - floating point estimate of the cost to the goal from state s
        '''
        return 0.0


class SearchNode:
    def __init__(self, s, A, parent=None, parent_action=None, cost=0):
        '''
        s - the state defining the search node
        A - list of actions
        parent - the parent search node
        parent_action - the action taken from parent to get to s
        '''
        self.parent = parent # another instance of search node
        self.cost = cost
        self.parent_action = parent_action # previous action (up down left right)
        self.state = s[:]
        self.actions = A[:]

    def __str__(self):
        '''
        Return a human readable description of the node
        '''
        return str(self.state) + ' ' + str(self.actions)+' '+str(self.parent)+' '+str(self.parent_action)
    def __lt__(self, other):
        return self.cost < other.cost

class PriorityQ:
    '''
    Priority queue implementation with quick access for membership testing
    Setup currently to only with the SearchNode class
    '''
    def __init__(self):
        '''
        Initialize an empty priority queue
        '''
        self.l = [] # list storing the priority q
        self.s = set() # set for fast membership testing

    def __contains__(self, x):
        '''
        Test if x is in the queue
        '''
        return x in self.s

    def push(self, x, cost):
        '''
        Adds an element to the priority queue.
        If the state already exists, we update the cost
        '''
        if x.state in self.s:
            return self.replace(x, cost)
        heapq.heappush(self.l, (cost, x))
        self.s.add(x.state)

    def pop(self):
        '''
        Get the value and remove the lowest cost element from the queue
        '''
        x = heapq.heappop(self.l)
        self.s.remove(x[1].state)
        return x[1]

    def peak(self):
        '''
        Get the value of the lowest cost element in the priority queue
        '''
        x = self.l[0]
        return x[1]

    def __len__(self):
        '''
        Return the number of elements in the queue
        '''
        return len(self.l)

    def replace(self, x, new_cost):
        '''
        Removes element x from the q and replaces it with x with the new_cost
        '''
        for y in self.l:
            if x.state == y[1].state:
                self.l.remove(y)
                self.s.remove(y[1].state)
                break
        heapq.heapify(self.l)
        self.push(x, new_cost)

    def get_cost(self, x):
        '''
        Return the cost for the search node with state x.state
        '''
        for y in self.l:
            if x.state == y[1].state:
                return y[0]

    def __str__(self):
        '''
        Return a string of the contents of the list
        '''
        return str(self.l)

def dfs(init_state, f, is_goal, actions):
    '''
    Perform depth first search on a grid map.

    init_state - the intial state on the map
    f - transition function of the form s_prime = f(s,a)
    is_goal - function taking as input a state s and returning True if its a goal state
    actions - set of actions which can be taken by the agent

    returns - ((path, action_path), visited) or None if no path can be found
    path - a list of tuples. The first element is the initial state followed by all states
        traversed until the final goal state
    action_path - the actions taken to transition from the initial state to goal state
    '''
    blankers = [] # empty blank list to return for no path areas
    frontier = [] # Search stack
    n0 = SearchNode(init_state, actions)
    visited = [] # visited nodes
    frontier.append(n0)
    while len(frontier) > 0:
        n_i = frontier.pop() # Pop the last item 
        if n_i.state not in visited:
            visited.append(n_i.state)
            if is_goal(n_i.state):
                return (backpath(n_i), visited)
            else:
                for a in actions:
                    s_prime = f(n_i.state, a)
                    n_prime = SearchNode(s_prime,actions, n_i, a)
                    frontier.append(n_prime)
    return ((blankers, blankers),visited)

def idfs(init_state, f, is_goal, actions, m):
    '''
    Perform iterative depth first search on a grid map.

    init_state - the intial state on the map
    f - transition function of the form s_prime = f(s,a)
    is_goal - function taking as input a state s and returning True if its a goal state
    actions - set of actions which can be taken by the agent

    returns - ((path, action_path), visited) or None if no path can be found
    path - a list of tuples. The first element is the initial state followed by all states
        traversed until the final goal state
    action_path - the actions taken to transition from the initial state to goal state
    '''
    blankers = [] # empty blank list to return for no path areas
    for depth in range(m):
        frontier = [] # Search stack
        n0 = SearchNode(init_state, actions)
        n0.depth = 0
        visited = {}
        frontier.append(n0)

        while len(frontier) > 0:
            n_i = frontier.pop()                            ## pop off the last element
            if n_i.state not in visited:
                visited[n_i.state] = depth
                if is_goal(n_i.state):
                    print(depth)
                    return (backpath(n_i), visited.keys())
                else:
                    for a in actions:
                        s_prime = f(n_i.state, a)
                        n_prime = SearchNode(s_prime, actions, n_i, a)
                        n_prime.depth = n_i.depth + 1
                        if n_prime.depth <= depth:
                            frontier.append(n_prime)
            else:
                if visited[n_i.state] > depth:
                    visited[n_i.state] = depth

    return ((blankers, blankers),visited)

def bfs(init_state, f, is_goal, actions):
    '''
    Perform breadth first search on a grid map.

    init_state - the intial state on the map
    f - transition function of the form s_prime = f(s,a)
    is_goal - function taking as input a state s and returning True if its a goal state
    actions - set of actions which can be taken by the agent

    returns - ((path, action_path), visited) or None if no path can be found
    path - a list of tuples. The first element is the initial state followed by all states
        traversed until the final goal state
    action_path - the actions taken to transition from the initial state to goal state
    '''
    blankers = [] # empty blank list to return for no path areas	
    frontier = [] # Frontier queue (FIFO)
    n0 = SearchNode(init_state, actions)
    visited = [] # visited nodes
    frontier.append(n0)
    while len(frontier) > 0:
        n_i = frontier.pop(0) # Pop the first item
        if is_goal(n_i.state):
           return (backpath(n_i), visited)
        elif n_i.state not in visited:
            visited.append(n_i.state)
            for a in actions:
                s_prime = f(n_i.state, a)
                n_prime = SearchNode(s_prime,actions, n_i, a)
                frontier.append(n_prime)
    return ((blankers, blankers),visited)

def make_cost(node):                                                                        ## takes a node and adds the correct value of cost for an action
    if node.parent is not NULL:                                                             ## if it's the origional node, then the cost is 0
        if node.parent_action in _ACTIONS:                                                  ## if the action is in the _ACTIONS (4 cardinal directions)
            node.cost = 1+node.parent.cost                                                  ## add 1 to the cost

        if node.parent_action in _ACTIONS_2:                                                ## if the action is in the _ACTIONS_2 (4 cardinal directions and 4 diagonals)
            if node.parent_action == 'u':                                                   ## if the direction moves in the up direction
                node.cost = 1+node.parent.cost                                              ## add 1 to the cost
            elif node.parent_action == 'd':                                                 ## if the direction moves in the down direction 
                node.cost = 1+node.parent.cost                                              ## add 1 to the cost
            elif node.parent_action == 'l':                                                 ## if the direction moves in the left direction 
                node.cost = 1+node.parent.cost                                              ## add 1 to the cost
            elif node.parent_action == 'r':                                                 ## if the direction moves in the right direction 
                node.cost = 1+node.parent.cost                                              ## add 1 to the cost
            elif node.parent_action == 'ne':                                                ## if the direction moves in the northeast (up-right) direction 
                node.cost = 1.5+node.parent.cost                                            ## add 1.5 to the cost
            elif node.parent_action == 'nw':                                                ## if the direction moves in the northwest (up-left) direction 
                node.cost = 1.5+node.parent.cost                                            ## add 1.5 to the cost
            elif node.parent_action == 'se':                                                ## if the direction moves in the southeast (down-right) direction 
                node.cost = 1.5+node.parent.cost                                            ## add 1.5 to the cost
            elif node.parent_action == 'sw':                                                ## if the direction moves in the southwest (up-left) direction 
                node.cost = 1.5+node.parent.cost                                            ## add 1.5 to the cost
        
        if node.parent_action in _2DACTIONS:                                                ## if the action is in the _2DACTIONS (forward, turning left, turning right)
            if node.parent_action == 'f':                                                   ## if the direction moves forward direction
                s = node.state                                                              ## get the state of the robot
                if s[_T] == 0 or s[_T] == 2 or s[_T] == 4 or s[_T] == 6:                    ## if the forward direction moves in one of the 4 cardinal direction
                    node.cost = 1+node.parent.cost                                          ## add 1 to the cost
                elif s[_T] == 1 or s[_T] == 3 or s[_T] == 5 or s[_T] == 7:                  ## if the forward direction moves in one of the 4 diagonal direction
                    node.cost = 1.5+node.parent.cost                                        ## add 1.5 to the cost
            elif node.parent_action == 'tl':                                                ## if the direction turns left direction
                node.cost = 0.25+node.parent.cost                                           ## add 0.25 to the cost
            elif node.parent_action == 'tr':                                                ## if the direction turn right direction
                node.cost = 0.25+node.parent.cost                                           ## add 0.25 to the cost
      
    return node                                                                             ## return the node

def uniform_cost_search(init_state, f, is_goal, actions):
    blankers = [] # empty blank list to return for no path areas	
    frontier = [] # Frontier queue (FIFO)
    n0 = SearchNode(init_state, actions)
    frontier = PriorityQ()
    visited = []                                        ## visited nodes
    frontier.push(n0, make_cost(n0))
    while len(frontier) > 0:
        n_i = frontier.pop() # Pop the first item
        if(n_i.state not in visited):
            visited.append(n_i.state)
            if is_goal(n_i.state):
               print("Total Goal Cost:", make_cost(n_i).cost)
               return (backpath(n_i), visited)
            else:
                for a in actions:
                    s_prime = f(n_i.state, a)
                    n_prime = SearchNode(s_prime,actions, n_i, a)
                    print(make_cost(n_prime).cost)                  ## proof the uniform cost is increasing
                    new_cost = make_cost(n_prime).cost
                    old_cost = frontier.get_cost(n_prime)
                    if old_cost == None or old_cost > new_cost:
                            frontier.push(n_prime, new_cost)
                    
    return ((blankers, blankers),visited)

def a_star_search(init_state, f, is_goal, actions, h):
    '''
    init_state - value of the initial state
    f - transition function takes input state (s), action (a), returns s_prime = f(s, a)
        returns s if action is not valid
    is_goal - takes state as input returns true if it is a goal state
        actions - list of actions available
    h - heuristic function, takes input s and returns estimated cost to goal
        (note h will also need access to the map, so should be a member function of GridMap)
    '''
    blankers = []                                                           ## empty blank list to return for no path areas	
    n0 = SearchNode(init_state, actions)                                    ##
    frontier = PriorityQ()                                                  ##    
    visited = []                                                            ## visited nodes    
    n0 = make_cost(n0)                                                      ## determines the first cost at the first node
    n0.cost_h = n0.cost + h(n0)                                             ## determines the first cost + heuristic value
    frontier.push(n0, n0.cost_h)                                            ##
    while len(frontier) > 0:
        n_i = frontier.pop() # Pop the first item
        if(n_i.state not in visited):
            visited.append(n_i.state)
            ## choose next based on uniform
            if is_goal(n_i.state):
               print("Total Goal Cost:", make_cost(n_i).cost)
               return (backpath(n_i), visited)
            else:
                for a in actions:
                    s_prime = f(n_i.state, a)
                    n_prime = SearchNode(s_prime,actions, n_i, a)
                    n_prime = make_cost(n_prime)
                    n_prime.cost_h = n_prime.cost + h(n_prime)
                    print("State")
                    print(n_prime.state)
                    print("Cost")
                    print(n_prime.cost)
                    print("H")
                    print(h(n_prime))
                    print("Total")
                    print(n_prime.cost_h)
                    new_cost = n_prime.cost_h
                    old_cost = frontier.get_cost(n_prime)
                    if old_cost == None or old_cost > new_cost:
                            frontier.push(n_prime, new_cost)
                    
    return ((blankers, blankers),visited)

def backpath(node):                                         ## determine the path that leads to the goal
    '''
    Function to determine the path that lead to the specified search node

    node - the SearchNode that is the end of the path

    returns - a tuple containing (path, action_path) which are lists respectively of the states
    visited from init to goal (inclusive) and the actions taken to make those transitions.
    '''
    path = []                                               ## initializes the path list (path from the initial to the destination)
    action_path = []                                        ## initializes the action_path list (all of the paths take to find the goal (areas visited))
    while node.parent:                                      ## checks if the node has a parent (reached initial state)
        action_path.insert(0,node.parent_action)            ## adds it to the front of the list
        path.insert(0,node.state)                           ## adds the state of the node to create the path
        node = node.parent                                  ## moves onto the parent node
    print(action_path)                                      ## prints out the actions taken to get the final path
    print(path)                                             ## prints out the path states taken in the final path
    return (path, action_path)                              ## returns the path and the action_path
